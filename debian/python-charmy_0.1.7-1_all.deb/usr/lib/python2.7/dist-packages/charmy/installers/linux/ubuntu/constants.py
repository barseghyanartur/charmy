LAUNCHER_CONTENT_PATTERN = """[Desktop Entry]
Version=1.0
Type=Application
Name=PyCharm Community Edition
Icon={icon_path}
Exec="{exec_path}" %f
Comment=Develop with pleasure!
Categories=Development;IDE;
Terminal=false
StartupWMClass=jetbrains-pycharm-ce
"""
